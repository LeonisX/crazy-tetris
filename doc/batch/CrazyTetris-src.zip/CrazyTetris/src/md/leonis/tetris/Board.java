package md.leonis.tetris;

import md.leonis.tetris.Figure;
import java.util.Arrays;
import java.awt.Color;

public class Board {
    int width, height;
    Color[][] glass;//, newGlass;
    int deleted[]=new int[4];
    public int deletedLines=0;
    public int falledFigure=255;

    public Board(int width, int height) {
        this.width=width;
        this.height=height;
        start();
    }

    public void start() {
        deletedLines=0;
        glass=new Color[width][height];
        for(int i=0;i<width;i++){
            for(int j=0;j<height;j++){
                glass[i][j]=new Color(0,0,0);
            }
        }
    }

    public void falled(Figure figure) {
        deletedLines=0;
        falledFigure=figure.type;
        for(int i=0;i<figure.x.length;i++) {
            glass[figure.x[i]+figure.left][figure.y[i]+figure.top]=figure.color;
        }
        int currentLine=height-1;
        for(int j=height-1;j>=0;j--) {
            boolean f=false;
            for(int i=0;i<width;i++) {
                if (glass[i][j].equals(Color.BLACK)) f=true;
            }
            if (f) {
                if (currentLine!=j) {
                    for(int i=0;i<width;i++) {
                        glass[i][currentLine]=glass[i][j];
                    }
                }
                currentLine--;
            } else {
                deleted[deletedLines]=j;
                deletedLines++;
            }
        }
        for(int j=0;j<currentLine;j++)
            for(int i=0;i<width;i++) glass[i][j]=Color.BLACK;
    }
}