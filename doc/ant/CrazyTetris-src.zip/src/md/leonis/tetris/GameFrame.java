package md.leonis.tetris;
/*
 * Демонстрация работы панелей, компоновки объектов, обработки событий
 * В этом примере показана симуляция центровки объектов, обработка
 * событий сразу от нескольких кнопок, динамическая смена панелей.

 * Написано для сайта tv-games.ru
 * (C) Leonis, 2015
 */

import md.leonis.tetris.Tetris;
import md.leonis.tetris.MusicChannel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
/*
 * Расширяем класс JFrame и строим в нём все наши компоненты
 */

public class GameFrame extends JFrame {
	private static final long serialVersionUID = 8767407735704287012L;
	public JPanel startPanel, pausePanel, recordPanel, recordPanel2; // будем менять эти панели
	public JButton saveButton;
	JButton continueButton;
	JButton startButton;
	public JLabel saveLabel;
	public GamePanel myPanel;
	final JTextField myTextField; // поле для ввода текста
	Tetris tetris;
	Monitor monitor;
	Records GameRecords;
	DefaultTableModel model;
	JTable table;
	BufferedImage frameBuffer;
	Image bg, title, ic;
	int height = 480;
	int width = 380;
	MusicChannel musicChannel;
	boolean crazy = false;

	GameFrame(String s) { // конструктор

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // при закрытии
														// закрывается окно
		setTitle(s);

		setSize(width, height); // габариты

		setLocationRelativeTo(null);

		myPanel = new GamePanel(); // основная панель
		myPanel.setFocusable(true);

		monitor = new GameMonitor();

		musicChannel = new MusicChannel("resources/audio/music.mp3");

		try {
			bg = ImageIO.read(new File("resources/bg.jpg"));
			title = ImageIO.read(new File("resources/title.jpg"));
		} catch (IOException e) {
		}
		ic = title;
		// отступы сверху и снизу по 170
		// так виртуально компоную содержимое панели в середине окна
		/*
		 * Что делается ниже: 1. Создаётся панель, разделённая на верх и низ. 2.
		 * В верхнюю часть размещаем текстовое сообщение, в нижнюю элементы
		 * управления 3. И так три раза для каждой из рабочих панелей
		 */
		startPanel = new JPanel();
		startPanel.setBorder(BorderFactory.createRaisedBevelBorder()); // рамка
																		// панели
		startPanel.setLayout(new GridLayout(3, 1)); // две ячейки
		startButton = new JButton("Обычная игра"); // создаём кнопку
		startButton.addActionListener(monitor); // слушатель событий кнопки
		startButton.setActionCommand("starta"); // команда, которая передаётся
												// слушателю
		JButton startButton2 = new JButton("Сумасшедшая игра"); // создаём
																// кнопку
		startButton2.addActionListener(monitor); // слушатель событий кнопки
		startButton2.setActionCommand("startb"); // команда, которая передаётся
													// слушателю

		JButton closeButton = new JButton("Выход");
		closeButton.setActionCommand("close");
		closeButton.addActionListener(monitor);
		startPanel.add(startButton); // добавляем кнопку в контейнер для нижней
										// ячейки
		startPanel.add(startButton2); // добавляем кнопку в контейнер для нижней
										// ячейки
		startPanel.add(closeButton); // вторая кнопка, будет справа от первой,
										// обе отцентрованы

		pausePanel = new JPanel();
		pausePanel.setBorder(BorderFactory.createRaisedBevelBorder());
		pausePanel.setLayout(new GridLayout(2, 1));
		pausePanel.add(new JLabel(" Для продолжения нажмите кнопку "));
		JPanel pausePanel2 = new JPanel();
		continueButton = new JButton("Тык");
		continueButton.addActionListener(monitor);
		continueButton.addKeyListener(monitor);
		continueButton.setActionCommand("continue");
		pausePanel2.add(continueButton);
		pausePanel.add(pausePanel2);

		recordPanel = new JPanel();
		recordPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		// recordPanel.setLayout(new GridLayout(4,1,0,0));
		recordPanel.setLayout(new BoxLayout(recordPanel, BoxLayout.Y_AXIS));
		recordPanel2 = new JPanel();
		saveLabel = new JLabel();
		recordPanel2.add(saveLabel); // "Новый рекорд! Ваше имя: "
		myTextField = new JTextField("", 16);
		recordPanel2.add(myTextField);
		JPanel recordPanel3 = new JPanel();
		saveButton = new JButton("Записать");
		recordPanel3.add(saveButton);
		saveButton.setActionCommand("save");
		saveButton.addActionListener(monitor);

		model = new DefaultTableModel();
		table = new JTable(model);
		model.addColumn("Имя");
		model.addColumn("Рекорд");
		// GameRecords.fillModel(model);

		recordPanel.add(table.getTableHeader(), BorderLayout.PAGE_START);
		recordPanel.add(table);
		recordPanel.add(recordPanel2);
		recordPanel.add(recordPanel3);

		myPanel.add(startPanel);
		myPanel.add(pausePanel);
		myPanel.add(recordPanel);
		add(myPanel);

		myPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 170, height / 3)); // выравнивание
																				// по
																				// горизонтали
																				// -
																				// по
																				// середине
		startPanel.setVisible(true);
		pausePanel.setVisible(false);
		recordPanel.setVisible(false);
		setVisible(true); // делаем видимым окно
		musicChannel.play();
		startButton.requestFocus();
	}

	class GamePanel extends JPanel {
		private static final long serialVersionUID = 1066938380146379137L;

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			frameBuffer = new BufferedImage(width, height,
					BufferedImage.TYPE_INT_ARGB);
			Graphics ge = frameBuffer.getGraphics();
			ge.drawImage(ic, 0, 0, null);
			ge.dispose();
			if (tetris != null)
				tetris.draw(frameBuffer.getGraphics());
			g.drawImage(frameBuffer, 0, 0, this);
		}
	}

	class GameMonitor extends Monitor {
		public void actionPerformed(ActionEvent e) {
			String s = e.getActionCommand(); // получаем команду
			if (s == "starta") {
				crazy = false;
				s = "start";
			}
			if (s == "startb") {
				crazy = true;
				s = "start";
			}
			if (s == "start") {
				ic = bg;
				System.out.println(1);
				musicChannel.stop();
				System.out.println(2);
				startPanel.setVisible(false);
				System.out.println(3);
				tetris = new Tetris();
				System.out.println(4);
				tetris.setCrazy(crazy);
				System.out.println(5);
				tetris.panel = myPanel;
				System.out.println(6);
				tetris.monitor = this;
				tetris.frameBuffer = frameBuffer;
				tetris.start();
				myPanel.addKeyListener(tetris);
				myPanel.addKeyListener(this);
				// GamePanel.removeKeyListener(tetris);
				// GamePanel.removeKeyListener(this);

			} else if (s == "continue") {
				pausePanel.setVisible(false);
				tetris.pause(false);

			} else if (s == "gameover") {
				if (crazy)
					s = "crazy.res";
				else
					s = "tet.res";
				GameRecords = new Records(s);
				int place = GameRecords.getPlace(tetris.score);
				if (GameRecords.verify(tetris.score)) {
					GameRecords.fillModel(model);
					myTextField.setVisible(true);
					saveButton.setText("Записать");
					switch (place) {
					case 1:
						saveLabel.setText("Первое место!!! Ваше имя: ");
						break;
					case 2:
						saveLabel.setText("Второе место!! Ваше имя: ");
						break;
					case 3:
						saveLabel.setText("Третье место! Ваше имя: ");
						break;
					default:
						saveLabel.setText(Integer.toString(tetris.score)
								+ " очков! Ваше имя: ");
					}
				} else {
					myTextField.setVisible(false);
					saveButton.setText("Тык");
					saveLabel
							.setText("Набрано " + Integer.toString(tetris.score)
									+ " очков. Маловато для рекорда!");
				}
				// выравнивание по горизонтали - по середине
				myPanel.setLayout(
						new FlowLayout(FlowLayout.CENTER, 170, height / 5)); 
				recordPanel.setVisible(true);
				if (place < 30)
					myTextField.requestFocus();
				else
					saveButton.requestFocus();
			} else if (s == "save") {
				recordPanel.setVisible(false);
				String str = myTextField.getText();
				if (str.length() == 0)
					str = "Капитан Немо";
				GameRecords.verifyAndAdd(str, tetris.score);
				GameRecords.save();
				// выравнивание по горизонтали - по середине
				myPanel.setLayout(
						new FlowLayout(FlowLayout.CENTER, 170, height / 3));
				startPanel.setVisible(true);
				startButton.requestFocus();
			} else if (s == "close") {
				if (tetris != null)
					tetris.finish();
				System.exit(0); // закрываем программу
			}
			myPanel.repaint(); // вызываем перерисовку панели
		}

		/*
		 * "Слушатель". Отвечает за интерфейс
		 */
		public void keyPressed(KeyEvent e) {
			int keyCode = e.getKeyCode();
			switch (keyCode) {
			case KeyEvent.VK_ESCAPE:
				tetris.finish();
				GameRecords.save();
				System.exit(0);
				break;
			case KeyEvent.VK_P:
				if (tetris.state == 1) {
					tetris.pause(true);
					// выравнивание по горизонтали - по середине
					myPanel.setLayout(
							new FlowLayout(FlowLayout.CENTER, 170, height / 3));
					pausePanel.setVisible(true);
					continueButton.requestFocus();
				} else if (tetris.state == 2) {
					pausePanel.setVisible(false);
					tetris.pause(false);
					System.out.println(tetris.state);
				}
				myPanel.repaint(); // вызываем перерисовку панели
				break;
			}
		}
	}
}