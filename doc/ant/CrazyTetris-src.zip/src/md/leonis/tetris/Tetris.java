package md.leonis.tetris;

import md.leonis.tetris.Board;
import md.leonis.tetris.Critter;
import md.leonis.tetris.SoundMonitor;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class Tetris extends KeyAdapter {
    final int NOTINIT=0;
    final int RUNNING=1;
    final int PAUSED=2;
    final int GAMEOVER=3;
    int nextLevel;
    int startLevel;
    int level;
    int score;
    int lines;
    int erasedLines;
    int tileWidth, tileHeight;
    int width=10, height=22;
    Board board;
    Figure figure, nextFigure;
    Critter critter;
    NextMove nm;
    NextFrame nf;
    JPanel panel;
    Monitor monitor;
    int state=NOTINIT;
    boolean crazy=false;
    BufferedImage frameBuffer;
    SoundMonitor soundMonitor;                    // монитор для звуковых эффектов


    public Tetris() {
        tileWidth=20;
        tileHeight=20;
        nextLevel=10000; //игра очень быстро заканчивается, вероятно надо увеличить
        startLevel=0;
        soundMonitor=new SoundMonitor();            // создаём монитор звуковых эффектов
        soundMonitor.addSound("resources/audio/falled.wav");        // 1 звук
        soundMonitor.addSound("resources/audio/rotate.wav");        // 2 звук
        soundMonitor.addSound("resources/audio/click.wav");         // 3 звук
        soundMonitor.addSound("resources/audio/heartbeat-a.wav");   // 4 звук
        soundMonitor.addSound("resources/audio/heartbeat-b.wav");   // 5 звук
        soundMonitor.setGain(0,0.9f);               // громкость (от 0 до 1.0f)
        soundMonitor.setGain(1,0.9f);
        soundMonitor.setGain(2,1.0f);
        soundMonitor.setGain(3,0.8f);
        soundMonitor.setGain(4,0.9f);
    }

    public void setCrazy(boolean crazy){
        this.crazy=crazy;
        if(crazy) {width=12; height=23;} else {width=10; height=22;}
    }

    public void start() {
        board=new Board(width, height);
        critter=new Critter(board.glass);
        level=startLevel;
        score=0;
        lines=0;
        erasedLines=0;
        Figure.crazy=crazy;
        makeNextFigure();
        next();
        nm=new NextMove();
        nf=new NextFrame();
        state=RUNNING;
        critter.start();
        nm.start();
        nf.start();
    }

    void makeNextFigure(){
        nextFigure=new Figure(board.glass);
    }

    void makeFigure(){
        figure=nextFigure;
        critter.setFigure(figure);
        makeNextFigure();
    }

    public void next() {
        if(state==GAMEOVER) return;
        if(state>NOTINIT) {
            soundMonitor.play(0);
            critter.paused=true;
            if (!critter.correct()) { finish(); return; }
            board.falled(figure);
            critter.correctY(board.deleted, board.deletedLines);
            critter.paused=false;
            score();
        }
        makeFigure();
        if (!critter.correct()) finish();
        if (!figure.correct()) finish();
    }

    public void pause(boolean paused) {
        if(paused) state=PAUSED; else state=RUNNING;
        critter.paused=paused;
    }

    public void finish() {
        critter.state=critter.DEAD;
        monitor.actionPerformed(new ActionEvent(monitor, ActionEvent.ACTION_PERFORMED, "gameover"));
        state=GAMEOVER;
    }

  /*
  "Слушатель". По требованию добавляет/убирает спрайты.
  */
  public void keyPressed(KeyEvent e) {
      if(state>=PAUSED) return;
      int keyCode=e.getKeyCode();
        switch (keyCode) {
          case KeyEvent.VK_LEFT:
            if(figure.moveLeft()) soundMonitor.play(2);
//            if(!critter.correct()) finish();
            break;
          case KeyEvent.VK_RIGHT:
            if(figure.moveRight()) soundMonitor.play(2);
//            if(!critter.correct()) finish();
            break;
          case KeyEvent.VK_DOWN:
            if(figure.moveDown()) soundMonitor.play(2);
//            if(!critter.correct()) finish();
            break;
          case KeyEvent.VK_UP:
            if(figure.rotateRight()) soundMonitor.play(1);
//            if(!critter.correct()) finish();
            break;
          case KeyEvent.VK_SPACE:
            figure.fall();
//            if(!critter.correct()) finish();
            next();
            break;
          case KeyEvent.VK_F12:
            score+=10000;
            score();
            break;
        }
  }

//3. Поток опускания фигуры - интервал зависит от скорости игры
    class NextMove extends Thread {
        public void run() {
            while(state<GAMEOVER) {
                if (state!=PAUSED) if (figure.falled) next();
                try {
                    sleep(1001-level*100);
//                    sleep(10001-level*100);
                }catch(InterruptedException e){}
                if (state!=PAUSED) if (!figure.falled) figure.moveDown();
            }
        }
    }

//2. Поток рисования - интервал 33 мс (30 кадров в секунду), больше не надо
    class NextFrame extends Thread {
        public void run() {
            while(state<GAMEOVER) {
                try {
                    sleep(33);
                }catch(InterruptedException e){}
                soundMonitor.schedule();
                int k=(critter.air<50) ? 1 : 0;
                if (critter.air<10) k=2;
                switch(k) {
                    case 2:                 //скоро конец
                        if (soundMonitor.isLooping(3)) soundMonitor.stop(3);
                        if (!soundMonitor.isLooping(4)) soundMonitor.loop(4);
                        break;
                    case 1:                 //задыхаюсь
                        if (soundMonitor.isLooping(4)) soundMonitor.stop(4);
                        if (!soundMonitor.isLooping(3)) soundMonitor.loop(3);
                        break;
                    default:                //всё хорошо
                        if ((soundMonitor.isLooping(3)) && (!soundMonitor.ac[3].fade)) soundMonitor.fade(3);
                        if (soundMonitor.isLooping(4)) soundMonitor.stop(4);
                }
                panel.repaint();
            }
        }
    }

    public void score() {
        lines+=board.deletedLines;
        switch(board.falledFigure) {
            case 0:
            case 6: score+=10;
                    break;
            case 1:
            case 2:
            case 3: score+=15;
                    break;
            case 4:
            case 5: score+=20;
        }
        switch(board.deletedLines) {
            case 1: score+=100;
                    break;
            case 2: score+=250;
                    break;
            case 3: score+=400;
                    break;
            case 4: score+=600;
        }
        level=score/nextLevel;
        board.deletedLines=0;
//        board.falledFigure=255;
    }

    public void draw(Graphics gx) {
//        g=frameBuffer.getGraphics();
        //рисуем стакан
        Graphics2D g = (Graphics2D) gx;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.translate(10,10);
        g.setColor(Color.BLACK);
        g.fillRect(0,0,width*tileWidth,(height-2)*tileHeight);
        g.setColor(new Color(100,100,100));
        for(int i=1;i<width;i++) {
           for(int j=3;j<height;j++) {
                g.drawRect(i*tileWidth, (j-2)*tileHeight,0,0);
           }
        }

        for(int i=0;i<width;i++) {
           for(int j=2;j<height;j++) {
                g.setColor(board.glass[i][j]);
                g.fillRoundRect(i*tileWidth, (j-2)*tileHeight, tileWidth-1, tileHeight-1, tileWidth/2, tileHeight/2);
           }
        }

        //выводим счёт, линии.
        int lpos=width*tileWidth+7;
        g.setColor(Color.BLACK);
        g.drawString("Счёт: "+score,lpos,10);
        g.drawString("Линий: "+lines,lpos,30);
        g.drawString("Уровень: "+level,lpos,50);
        String st="Жизнь прекрасна :)";
        if (critter.air<75) st="Надо отдышаться...";
        if (critter.isBlocked()) if (critter.air<50) st="Задыхаюсь!!!"; else st="Тут мало воздуха...";
        g.drawString("Дыхание: "+(int)critter.air+"%",lpos,70);
        g.drawString(st,lpos,90);

        //рисуем фигуру
        for(int i=0;i<figure.x.length;i++) {
            int k=figure.ghostTop();
            g.setColor(new Color(figure.color.getRed()/7,figure.color.getGreen()/7,figure.color.getBlue()/4));
            if ((figure.y[i]+k)>=2)
                g.fillRoundRect((figure.x[i]+figure.left)*tileWidth, (figure.y[i]+k-2)*tileHeight, tileWidth-1, tileHeight-1, tileWidth/2, tileHeight/2);
        }

        int kx=0;
        for(int i=0;i<nextFigure.x.length;i++) if (nextFigure.x[i]<kx) kx=nextFigure.x[i];
        int ky=0;
        for(int i=0;i<nextFigure.y.length;i++) if (nextFigure.y[i]<ky) ky=nextFigure.y[i];

        for(int i=0;i<nextFigure.x.length;i++) {
            g.setColor(new Color(figure.color.getRed()/4,figure.color.getGreen()/4,figure.color.getBlue()/3));
            g.fillRoundRect((nextFigure.x[i]-kx)*tileWidth+lpos+1, (nextFigure.y[i]-ky)*tileHeight+100+1, tileWidth-1, tileHeight-1, tileWidth/2, tileHeight/2);

            g.setColor(nextFigure.color);
            g.fillRoundRect((nextFigure.x[i]-kx)*tileWidth+lpos, (nextFigure.y[i]-ky)*tileHeight+100, tileWidth-1, tileHeight-1, tileWidth/2, tileHeight/2);

        }

        for(int i=0;i<figure.x.length;i++) {
            g.setColor(figure.color);
            if ((figure.y[i]+figure.top)>=2)
                g.fillRoundRect((figure.x[i]+figure.left)*tileWidth, (figure.y[i]+figure.top-2)*tileHeight, tileWidth-1, tileHeight-1, tileWidth/2, tileHeight/2);
        }

        //рисую персонажа
        if (critter.state!=critter.DEAD) {
            g.setColor(Color.WHITE);
            g.drawOval(critter.x*tileWidth, (critter.y-2)*tileHeight, tileWidth, tileHeight);
            kx=critter.direction*2;
            ky=0;
            if (critter.state==critter.FALLING) ky=1;
            if (critter.state==critter.JUMPING) ky=-1;
            if (critter.state==critter.STAYING) kx=0;
            //глаза
            g.drawArc(critter.x*tileWidth+7+kx, (critter.y-2)*tileHeight+6+ky, 1,1,0,360);
            g.drawArc(critter.x*tileWidth+12+kx, (critter.y-2)*tileHeight+6+ky, 1,1,0,360);
            //глаза
            if (critter.air<50) {
                g.drawRect(critter.x*tileWidth+7+kx+1, (critter.y-2)*tileHeight+6+ky-1, 0,0);
                g.drawRect(critter.x*tileWidth+12+kx, (critter.y-2)*tileHeight+6+ky-1, 0,0);
            }
            //рот
            int wx;
            if (critter.isBlocked()) wx=2; else wx=6;
            if ((critter.air>75) && (!critter.isBlocked())) {
                  g.drawArc(critter.x*tileWidth+7+kx-1, (critter.y-2)*tileHeight+14-3, wx+2, 3, 0, -180);
            } else g.drawRect(critter.x*tileWidth+7+kx+(6-wx)/2, (critter.y-2)*tileHeight+14, wx,0);

        }
//        g.translate(0,0);
    }
}

abstract class Monitor implements ActionListener, KeyListener {
  abstract public void actionPerformed(ActionEvent e);
  abstract public void keyPressed(KeyEvent e);
  public void keyReleased(KeyEvent e) {}
  public void keyTyped(KeyEvent e) {}
}
