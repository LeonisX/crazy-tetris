//баг - в рекордах можно нажать паузу
//некрасиво - board является владельцем figure. В идеале Tetris должен владеть figure


package md.leonis.tetris;
/*
 * Демонстрация работы панелей, компоновки объектов, обработки событий
 * В этом примере показана симуляция центровки объектов, обработка
 * событий сразу от нескольких кнопок, динамическая смена панелей.

 * Написано для сайта tv-games.ru
 * (C) Leonis, 2015
 */

import md.leonis.tetris.GameFrame;

/*
 * Отсюда начинается выполнение программы
 */
public class CrazyTetris {
  public static void main(String[] args) {
    javax.swing.SwingUtilities.invokeLater(new Runnable() {
        public void run() {
            GameFrame myWindow = new GameFrame("Crazy Tetris");				// рабочее окно
            myWindow.setResizable(false);
        }
    });
  }
}